"use strict";
exports.id = 555;
exports.ids = [555];
exports.modules = {

/***/ 9555:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_loader_spinner__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1223);
/* harmony import */ var react_loader_spinner__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_loader_spinner__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);



const Form = (props)=>{
    const withCommonParent = props?.FormProps?.inputs.filter((i)=>i.needCommonParent);
    const withoutCommonParent = props?.FormProps?.inputs.filter((i)=>!i.needCommonParent);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
        className: props?.FormProps?.formClassName,
        onSubmit: props?.FormProps?.submit,
        ref: props?.FormProps?.ref,
        name: props?.FormProps?.name,
        children: [
            props?.FormProps?.needClose ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: props?.FormProps?.closeClassname,
                onClick: props?.FormProps?.hendler,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                    className: props?.FormProps?.closeLogoClassname,
                    src: props?.FormProps?.closeSrc,
                    alt: "main logo",
                    width: 20,
                    height: 20
                })
            }) : null,
            props?.FormProps?.needTitle ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                className: props?.FormProps?.titleClassname,
                children: props?.FormProps?.title
            }) : null,
            withCommonParent?.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: props?.FormProps?.inputsCommonParentClass,
                children: withCommonParent?.map((input)=>{
                    const attrs = {
                        type: input.type,
                        name: input.name,
                        id: input.name,
                        placeholder: input.placeholder,
                        className: input.className,
                        [input.eventType]: input.callBack
                    };
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        ...attrs
                    }, input.id);
                })
            }) : null,
            withoutCommonParent?.length ? withoutCommonParent.map((input)=>{
                const attrs = {
                    type: input.type,
                    name: input.name,
                    id: input.name,
                    placeholder: input.placeholder,
                    className: input.className,
                    [input.eventType]: input.callBack
                };
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    ...attrs
                }, input.id);
            }) : null,
            props?.FormProps?.needTextareas ? props.FormProps.textareas.map((textarea)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                    className: textarea?.textareaClass,
                    name: textarea?.textareaName,
                    placeholder: textarea?.textareaPlaceholder
                }, textarea?.id);
            }) : null,
            props?.FormProps?.needFileUploader ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                type: "file",
                className: props?.FormProps?.fileUploaderClass,
                multiple: props?.FormProps?.multiple,
                name: props?.FormProps?.fileUploaderName
            }, Math.random().toString()) : null,
            props?.FormProps?.needButton ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                type: "submit",
                className: props?.FormProps?.buttonClass,
                onClick: props?.FormProps?.ButtoncallBack,
                children: props?.FormProps?.buttonText
            }) : null,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: props.loadrConteinerClassname,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_loader_spinner__WEBPACK_IMPORTED_MODULE_1__.Oval, {
                    height: 30,
                    width: 30,
                    color: "#4fa94d",
                    wrapperStyle: {},
                    wrapperClass: "",
                    visible: props.Loader ? props.Loader : false,
                    ariaLabel: "oval-loading",
                    secondaryColor: "#4fa94d",
                    strokeWidth: 2,
                    strokeWidthSecondary: 2
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Form);


/***/ })

};
;