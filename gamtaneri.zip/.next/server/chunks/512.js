exports.id = 512;
exports.ids = [512];
exports.modules = {

/***/ 6346:
/***/ ((module) => {

// Exports
module.exports = {
	"conteiner": "login_conteiner__4lxL_",
	"form_conteiner": "login_form_conteiner__RKPQ0",
	"login_form_title": "login_login_form_title__4VOVJ",
	"form_loader_conteiner": "login_form_loader_conteiner__jJYRB",
	"login_spiner_conteiner": "login_login_spiner_conteiner__u_xcG"
};


/***/ }),

/***/ 7512:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _context_locale_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4757);
/* harmony import */ var _form_form_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9555);
/* harmony import */ var _login_module_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6346);
/* harmony import */ var _login_module_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_login_module_css__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_loader_spinner__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1223);
/* harmony import */ var react_loader_spinner__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_loader_spinner__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var crypto_js_aes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2837);
/* harmony import */ var crypto_js_aes__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(crypto_js_aes__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5666);
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _context_admin_auth_context__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1625);










const Login = ()=>{
    const { 0: localeKey , 1: setLocaleKey  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const LocalCntextObject = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_locale_context__WEBPACK_IMPORTED_MODULE_2__/* .localeContext */ .A);
    const { 0: dictionary , 1: setDictionary  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: needLoader , 1: setNeedLoader  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const needRedairect = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(false);
    const { 0: showSpinner , 1: setShowSpinner  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const isVeriyfied = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(false);
    const authContextObject = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_admin_auth_context__WEBPACK_IMPORTED_MODULE_8__/* .authContext */ .g);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        (async ()=>{
            if (!isVeriyfied.current) {
                isVeriyfied.current = true;
                setLocaleKey(LocalCntextObject.localeKey);
                setDictionary(LocalCntextObject.dictionary);
                if (localStorage.getItem("_token")) {
                    await fetch("/api/admin/verify", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({
                            token: crypto_js_aes__WEBPACK_IMPORTED_MODULE_6___default().decrypt(localStorage.getItem("_token"), "secretPassphrase").toString(crypto_js__WEBPACK_IMPORTED_MODULE_7__.enc.Utf8)
                        })
                    }).then(async (res)=>await res.json()).then(async (data)=>{
                        if (await data && await data.isValid) {
                            authContextObject.setUser(data.user);
                            const token = crypto_js_aes__WEBPACK_IMPORTED_MODULE_6___default().encrypt(data.user.token, "secretPassphrase").toString();
                            localStorage.setItem("_token", token);
                            needRedairect.current = true;
                            setShowSpinner(false);
                        } else if (await data && !await data.isValid) {
                            router.push("/admin/login");
                            setShowSpinner(false);
                        } else {
                            throw new Error("Something went wrong");
                        }
                    }).catch((err)=>{
                        throw err;
                    }).finally(()=>{
                        setShowSpinner(false);
                    });
                } else {
                    setShowSpinner(false);
                }
            }
        })();
    }, [
        LocalCntextObject,
        authContextObject,
        showSpinner,
        router
    ]);
    if (needRedairect.current) {
        router.push("/admin/dashboard");
    } else {
        const requestBody = {
            email: "",
            password: ""
        };
        /**
     * @description this is login function
     * @param {Event} e
     */ const loginHendler = async (e)=>{
            e.preventDefault();
            let params = {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "accept-control-allow-origin": "*"
                },
                body: JSON.stringify(requestBody)
            };
            setNeedLoader(true);
            await fetch("/api/admin/login", params).then((res)=>res.json()).then((data)=>{
                setNeedLoader(false);
                if (data.user && data.user.token && data.user.token !== "") {
                    const token = crypto_js_aes__WEBPACK_IMPORTED_MODULE_6___default().encrypt(data.user.token, "secretPassphrase");
                    localStorage.setItem("_token", token.toString());
                    authContextObject.setUser(data.user);
                    router.push("/admin/dashboard");
                } else if (data && data.message === "Invalid Password") {} else if (data && data.message === "Invalid Email, or user not exit") {
                    console.log(data.message);
                } else {
                    console.log("something went wrong");
                }
            });
        };
        const getvalues = async (e)=>{
            e.preventDefault();
            if (e.currentTarget.name === "email") {
                requestBody.email = e.currentTarget.value;
            }
            if (e.currentTarget.name === "password") {
                requestBody.password = e.currentTarget.value;
            }
        };
        const formInputs = [
            {
                id: Math.random().toString(),
                type: "Email",
                name: "email",
                className: "form-input",
                placeholder: dictionary ? dictionary[localeKey]["email"] : "ელ.ფოსტა",
                needCommonParent: false,
                eventType: "onChange",
                callBack: getvalues
            },
            {
                id: Math.random().toString(),
                type: "password",
                name: "password",
                className: "form-input",
                placeholder: dictionary ? dictionary[localeKey]["password"] : "პაროლი",
                needCommonParent: false,
                eventType: "onChange",
                callBack: getvalues
            }, 
        ];
        const FomrProps = {
            formClassName: "form",
            inputs: formInputs,
            inputsCommonParentClass: "inputs_common_parent",
            needTextareas: false,
            needButton: true,
            buttonClass: "form_button",
            buttonText: LocalCntextObject.dictionary ? LocalCntextObject.dictionary[LocalCntextObject.localeKey]["login"] : "შესვლა",
            ButtoncallBack: loginHendler
        };
        if (showSpinner) {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_login_module_css__WEBPACK_IMPORTED_MODULE_9___default().login_spiner_conteiner),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_loader_spinner__WEBPACK_IMPORTED_MODULE_5__.Oval, {
                    height: 30,
                    width: 30,
                    color: "#4fa94d",
                    wrapperStyle: {},
                    wrapperClass: "",
                    visible: showSpinner,
                    ariaLabel: "oval-loading",
                    secondaryColor: "#4fa94d",
                    strokeWidth: 2,
                    strokeWidthSecondary: 2
                })
            });
        } else {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_login_module_css__WEBPACK_IMPORTED_MODULE_9___default().conteiner),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_login_module_css__WEBPACK_IMPORTED_MODULE_9___default().form_conteiner),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: (_login_module_css__WEBPACK_IMPORTED_MODULE_9___default().login_form_title),
                                children: "შესვლა"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_form_form_component__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                FormProps: FomrProps,
                                Loader: needLoader,
                                loadrConteinerClassname: (_login_module_css__WEBPACK_IMPORTED_MODULE_9___default().form_loader_conteiner)
                            })
                        ]
                    })
                })
            });
        }
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Login);


/***/ }),

/***/ 1625:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ AuthProvider),
/* harmony export */   "g": () => (/* binding */ authContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const authContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(null);
const AuthProvider = ({ children  })=>{
    const { 0: user , 1: setUser  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const value = {
        user,
        setUser
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(authContext.Provider, {
        value: value,
        children: children
    });
};


/***/ })

};
;