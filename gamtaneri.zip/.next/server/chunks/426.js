exports.id = 426;
exports.ids = [426];
exports.modules = {

/***/ 756:
/***/ ((module) => {

// Exports
module.exports = {
	"main_button": "button_main_button__e512R"
};


/***/ }),

/***/ 2849:
/***/ ((module) => {

// Exports
module.exports = {
	"gallery_conteiner": "gallery_gallery_conteiner__vJUIG",
	"gallery_image_main_conteiner": "gallery_gallery_image_main_conteiner__fRkfo"
};


/***/ }),

/***/ 7021:
/***/ ((module) => {

// Exports
module.exports = {
	"modal_background": "modal_modal_background__0O9gp",
	"modal_conteiner": "modal_modal_conteiner__K2ZT9",
	"modal": "modal_modal__95EBg",
	"modal_form_conteiner": "modal_modal_form_conteiner__mK5m7",
	"modal_title_conteiner": "modal_modal_title_conteiner__6Fcpw"
};


/***/ }),

/***/ 5154:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _button_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(756);
/* harmony import */ var _button_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_button_module_css__WEBPACK_IMPORTED_MODULE_1__);


const Button = (props)=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "button-conteiner",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
            className: (_button_module_css__WEBPACK_IMPORTED_MODULE_1___default().main_button),
            onClick: props.hendler,
            children: props.name
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Button);


/***/ }),

/***/ 4461:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ modal_component)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./components/form/form.component.tsx
var form_component = __webpack_require__(9555);
// EXTERNAL MODULE: ./components/modal/modal.module.css
var modal_module = __webpack_require__(7021);
var modal_module_default = /*#__PURE__*/__webpack_require__.n(modal_module);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/gallery/gallery.module.css
var gallery_module = __webpack_require__(2849);
var gallery_module_default = /*#__PURE__*/__webpack_require__.n(gallery_module);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/gallery/gallery.component.tsx




const Gallery = ()=>{
    const { 0: mainImage , 1: setMainImage  } = (0,external_react_.useState)("");
    return /*#__PURE__*/ jsx_runtime_.jsx(external_react_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (gallery_module_default()).gallery_conteiner,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (gallery_module_default()).gallery_image_main_conteiner,
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: mainImage,
                        alt: "gallery_main_image",
                        width: 700,
                        height: 550
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (gallery_module_default()).gallery_images_conteiner,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (gallery_module_default()).gallery_images_item,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: mainImage,
                            alt: "gallery_main_image",
                            width: 700,
                            height: 550
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const gallery_component = (Gallery);

;// CONCATENATED MODULE: ./components/modal/modal.component.tsx




const Modal = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: props?.modalprops?.isOpen ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (modal_module_default()).modal_conteiner,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (modal_module_default()).modal_background
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (modal_module_default()).modal,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (modal_module_default()).modal_form_conteiner,
                        children: [
                            props?.modalprops?.key === "FORM" ? /*#__PURE__*/ jsx_runtime_.jsx(form_component/* default */.Z, {
                                FormProps: props?.modalprops?.FormProps
                            }) : null,
                            props?.modalprops?.key === "GALLERY" ? /*#__PURE__*/ jsx_runtime_.jsx(gallery_component, {}) : null
                        ]
                    })
                })
            ]
        }) : null
    });
};
/* harmony default export */ const modal_component = (Modal);


/***/ })

};
;