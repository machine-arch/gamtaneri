"use strict";
exports.id = 757;
exports.ids = [757];
exports.modules = {

/***/ 4757:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ localeContext),
/* harmony export */   "I": () => (/* binding */ LocaleProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_2__);



const localeContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(null);
const LocaleProvider = ({ children  })=>{
    const { 0: dictionary , 1: setDictionary  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: localeKey , 1: setLocaleKey  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        /**
     * @description this function is used to get to fetch dictionary object from locale json file
     * @returns
     */ fetch("/locale/locale.json", {
            method: "GET"
        }).then((res)=>{
            return res.json();
        }).then((data)=>{
            setDictionary(data);
        });
        /**
     * @description  set locale key from cookies if it exists, if not set default locale in cookies
     */ if (!nookies__WEBPACK_IMPORTED_MODULE_2___default().get(null, "locale").locale) {
            nookies__WEBPACK_IMPORTED_MODULE_2___default().set(null, "locale", "ka", {
                path: "/",
                maxAge: 30 * 24 * 60 * 60
            });
            setLocaleKey("ka");
        } else {
            setLocaleKey(nookies__WEBPACK_IMPORTED_MODULE_2___default().get(null, "locale").locale);
        }
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(localeContext.Provider, {
        value: {
            localeKey,
            dictionary,
            setLocaleKey
        },
        children: children
    });
};


/***/ })

};
;