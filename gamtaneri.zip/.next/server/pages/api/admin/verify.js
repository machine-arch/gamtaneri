"use strict";
(() => {
var exports = {};
exports.id = 908;
exports.ids = [908];
exports.modules = {

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 3053:
/***/ ((module) => {

module.exports = require("nookies");

/***/ }),

/***/ 3236:
/***/ ((module) => {

module.exports = require("reflect-metadata");

/***/ }),

/***/ 1395:
/***/ ((module) => {

module.exports = import("tslib");;

/***/ }),

/***/ 2375:
/***/ ((module) => {

module.exports = import("typeorm");;

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 4753:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _src_config_ormConfig__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3477);
/* harmony import */ var _src_entity_user_entity__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2180);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9344);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_config_ormConfig__WEBPACK_IMPORTED_MODULE_0__, _src_entity_user_entity__WEBPACK_IMPORTED_MODULE_1__]);
([_src_config_ormConfig__WEBPACK_IMPORTED_MODULE_0__, _src_entity_user_entity__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const CheckToken = async (req, res)=>{
    if (req.method === "POST") {
        const Connection = _src_config_ormConfig__WEBPACK_IMPORTED_MODULE_0__/* ["default"].isInitialized */ .Z.isInitialized ? _src_config_ormConfig__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z : await _src_config_ormConfig__WEBPACK_IMPORTED_MODULE_0__/* ["default"].initialize */ .Z.initialize();
        const { token  } = req.body;
        const user = await Connection?.manager?.findOne(_src_entity_user_entity__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
            where: {
                token
            }
        });
        if (user) {
            try {
                jsonwebtoken__WEBPACK_IMPORTED_MODULE_2___default().verify(token, process.env.JWT_SECRET);
                res.setHeader("Content-Type", "application/json").json({
                    user,
                    isValid: true,
                    status: 200
                });
            } catch (error) {
                const refreshToken = nookies__WEBPACK_IMPORTED_MODULE_3___default().get({
                    req
                })["refreshToken"];
                if (refreshToken) {
                    try {
                        jsonwebtoken__WEBPACK_IMPORTED_MODULE_2___default().verify(refreshToken, process.env.JWT_SECRET);
                        const accesToken = jsonwebtoken__WEBPACK_IMPORTED_MODULE_2___default().sign({
                            id: user.id,
                            email: user.email
                        }, process.env.JWT_SECRET, {
                            expiresIn: "2h"
                        });
                        user.token = accesToken;
                        const date = new Date();
                        date.setHours(date.getHours() + 2);
                        user.tokenExpire = date;
                        await Connection.manager.save(user);
                        res.setHeader("Content-Type", "application/json").json({
                            user,
                            isValid: true,
                            status: 200
                        });
                    } catch (error1) {
                        res.setHeader("Content-Type", "application/json").json({
                            isValid: false,
                            status: 401
                        });
                    }
                } else {
                    res.setHeader("Content-Type", "application/json").json({
                        message: "no refresh token",
                        status: 401,
                        errorType: "unauthorized",
                        isValid: false
                    });
                }
            }
        } else {
            res.setHeader("Content-Type", "application/json").json({
                message: "no user found",
                status: 401,
                errorType: "unauthorized",
                isValid: false
            });
        }
        if (Connection.isInitialized) await Connection.destroy();
    } else {
        res.setHeader("Content-Type", "application/json").json({
            message: "Invalid Method",
            status: 405,
            errorType: "method_not_allowed",
            isValid: false
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CheckToken);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [477], () => (__webpack_exec__(4753)));
module.exports = __webpack_exports__;

})();