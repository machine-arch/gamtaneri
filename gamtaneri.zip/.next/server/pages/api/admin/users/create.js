"use strict";
(() => {
var exports = {};
exports.id = 609;
exports.ids = [609];
exports.modules = {

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 3236:
/***/ ((module) => {

module.exports = require("reflect-metadata");

/***/ }),

/***/ 1395:
/***/ ((module) => {

module.exports = import("tslib");;

/***/ }),

/***/ 2375:
/***/ ((module) => {

module.exports = import("typeorm");;

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 8201:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _src_entity_user_entity__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2180);
/* harmony import */ var _src_entity_ourusers_entity__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4488);
/* harmony import */ var _src_config_ormConfig__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3477);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9344);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_entity_user_entity__WEBPACK_IMPORTED_MODULE_0__, _src_entity_ourusers_entity__WEBPACK_IMPORTED_MODULE_1__, _src_config_ormConfig__WEBPACK_IMPORTED_MODULE_2__]);
([_src_entity_user_entity__WEBPACK_IMPORTED_MODULE_0__, _src_entity_ourusers_entity__WEBPACK_IMPORTED_MODULE_1__, _src_config_ormConfig__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const CreateUser = async (req, res)=>{
    if (req.method === "POST") {
        const { token , title , title_eng , description , description_eng  } = req.body;
        const Connection = _src_config_ormConfig__WEBPACK_IMPORTED_MODULE_2__/* ["default"].isInitialized */ .Z.isInitialized ? _src_config_ormConfig__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z : await _src_config_ormConfig__WEBPACK_IMPORTED_MODULE_2__/* ["default"].initialize */ .Z.initialize();
        const { email  } = jsonwebtoken__WEBPACK_IMPORTED_MODULE_3___default().decode(token, {
            json: true
        });
        const user = await Connection.getRepository(_src_entity_user_entity__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z).findOne({
            where: {
                email: email
            }
        });
        if (user) {
            if (jsonwebtoken__WEBPACK_IMPORTED_MODULE_3___default().verify(token, process.env.JWT_SECRET)) {
                const ourUser = new _src_entity_ourusers_entity__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z();
                ourUser.title = title;
                ourUser.title_eng = title_eng;
                ourUser.description = description;
                ourUser.description_eng = description_eng;
                ourUser.createdAt = new Date();
                ourUser.updatedAt = new Date();
                await Connection.getRepository(_src_entity_ourusers_entity__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z).save(ourUser);
                res.status(200).json({
                    message: "User created",
                    status: 200,
                    success: true
                });
            } else {
                res.json({
                    message: "Token not valid",
                    status: 401,
                    success: false
                });
            }
        } else {
            res.status(400).json({
                message: "User not found",
                status: 404,
                success: false
            });
        }
        Connection.isInitialized ? Connection.destroy() : null;
    } else {
        res.json({
            message: "Method not allowed",
            status: 405,
            success: false
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreateUser);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [477], () => (__webpack_exec__(8201)));
module.exports = __webpack_exports__;

})();