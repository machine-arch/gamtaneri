"use strict";
(() => {
var exports = {};
exports.id = 679;
exports.ids = [679];
exports.modules = {

/***/ 8432:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 3053:
/***/ ((module) => {

module.exports = require("nookies");

/***/ }),

/***/ 3236:
/***/ ((module) => {

module.exports = require("reflect-metadata");

/***/ }),

/***/ 1395:
/***/ ((module) => {

module.exports = import("tslib");;

/***/ }),

/***/ 2375:
/***/ ((module) => {

module.exports = import("typeorm");;

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 5284:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _src_entity_user_entity__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2180);
/* harmony import */ var _src_config_ormConfig__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3477);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9344);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8432);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(bcryptjs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3053);
/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_entity_user_entity__WEBPACK_IMPORTED_MODULE_0__, _src_config_ormConfig__WEBPACK_IMPORTED_MODULE_1__]);
([_src_entity_user_entity__WEBPACK_IMPORTED_MODULE_0__, _src_config_ormConfig__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const Auth = async (req, res)=>{
    if (req.method === "POST") {
        const Connection = await _src_config_ormConfig__WEBPACK_IMPORTED_MODULE_1__/* ["default"].initialize */ .Z.initialize();
        const tokenExpairy = "2h";
        const { email , password  } = req.body;
        const user = await Connection?.manager?.findOne(_src_entity_user_entity__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z, {
            where: {
                email
            }
        });
        if (user) {
            if (bcryptjs__WEBPACK_IMPORTED_MODULE_3___default().compareSync(password, user.password)) {
                const accesToken = jsonwebtoken__WEBPACK_IMPORTED_MODULE_2___default().sign({
                    id: user.id,
                    email: user.email
                }, process.env.JWT_SECRET, {
                    expiresIn: tokenExpairy
                });
                const refreshToken = jsonwebtoken__WEBPACK_IMPORTED_MODULE_2___default().sign({
                    id: user.id,
                    email: user.email
                }, process.env.JWT_SECRET, {
                    expiresIn: "2d"
                });
                nookies__WEBPACK_IMPORTED_MODULE_4___default().set({
                    res
                }, "refreshToken", refreshToken, {
                    path: "/",
                    maxAge: 86400,
                    sameSite: "strict",
                    httpOnly: true,
                    secure: true
                });
                user.token = accesToken;
                const date = new Date();
                date.setHours(date.getHours() + 2);
                user.tokenExpire = date;
                await Connection.manager.save(user);
                res.status(200).setHeader("Content-Type", "application/json").json({
                    user
                });
            } else {
                res.setHeader("Content-Type", "application/json").json({
                    message: "Invalid Password",
                    status: 401,
                    errorType: "unauthorized"
                });
            }
        } else {
            res.setHeader("Content-Type", "application/json").json({
                message: "Invalid Email, or user not exit",
                status: 401,
                errorType: "unauthorized"
            });
        }
        if (Connection.isInitialized) await Connection.destroy();
    } else {
        res.setHeader("Content-Type", "application/json").json({
            message: "Invalid Method",
            status: 405,
            errorType: "method_not_allowed"
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Auth);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [477], () => (__webpack_exec__(5284)));
module.exports = __webpack_exports__;

})();