"use strict";
(() => {
var exports = {};
exports.id = 992;
exports.ids = [992];
exports.modules = {

/***/ 1529:
/***/ ((module) => {

module.exports = require("formidable-serverless");

/***/ }),

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 3236:
/***/ ((module) => {

module.exports = require("reflect-metadata");

/***/ }),

/***/ 3673:
/***/ ((module) => {

module.exports = require("slugify");

/***/ }),

/***/ 1395:
/***/ ((module) => {

module.exports = import("tslib");;

/***/ }),

/***/ 2375:
/***/ ((module) => {

module.exports = import("typeorm");;

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 6711:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var formidable_serverless__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1529);
/* harmony import */ var formidable_serverless__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(formidable_serverless__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1017);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _src_entity_user_entity__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2180);
/* harmony import */ var _src_entity_complatedprojects_entity__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1403);
/* harmony import */ var _src_config_ormConfig__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3477);
/* harmony import */ var slugify__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3673);
/* harmony import */ var slugify__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(slugify__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9344);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_entity_user_entity__WEBPACK_IMPORTED_MODULE_2__, _src_entity_complatedprojects_entity__WEBPACK_IMPORTED_MODULE_3__, _src_config_ormConfig__WEBPACK_IMPORTED_MODULE_4__]);
([_src_entity_user_entity__WEBPACK_IMPORTED_MODULE_2__, _src_entity_complatedprojects_entity__WEBPACK_IMPORTED_MODULE_3__, _src_config_ormConfig__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const config = {
    api: {
        bodyParser: false
    }
};
const form = new (formidable_serverless__WEBPACK_IMPORTED_MODULE_0___default().IncomingForm)({
    multiples: true,
    uploadDir: path__WEBPACK_IMPORTED_MODULE_1___default().join(process.cwd(), "public", "uploads"),
    keepFilenames: true
});
const filePaths = [];
form.on("fileBegin", (name, file)=>{
    file.path = path__WEBPACK_IMPORTED_MODULE_1___default().join(form.uploadDir, slugify__WEBPACK_IMPORTED_MODULE_5___default()(file.name));
    filePaths.push(path__WEBPACK_IMPORTED_MODULE_1___default().relative(process.cwd(), file.path));
});
const CreateProject = async (req, res)=>{
    form.parse(req, async (err, fields, files)=>{
        if (req.method === "POST") {
            const Connection = _src_config_ormConfig__WEBPACK_IMPORTED_MODULE_4__/* ["default"].isInitialized */ .Z.isInitialized ? _src_config_ormConfig__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z : await _src_config_ormConfig__WEBPACK_IMPORTED_MODULE_4__/* ["default"].initialize */ .Z.initialize();
            const { project_name , project_name_eng , description , description_eng , token ,  } = fields;
            console.log(fields);
            const { email  } = jsonwebtoken__WEBPACK_IMPORTED_MODULE_6___default().decode(token, {
                json: true
            });
            const user = Connection?.manager?.findOne(_src_entity_user_entity__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                where: {
                    email
                }
            });
            if (user) {
                try {
                    jsonwebtoken__WEBPACK_IMPORTED_MODULE_6___default().verify(token, process.env.JWT_SECRET);
                    const project = new _src_entity_complatedprojects_entity__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z();
                    project.project_name = project_name;
                    project.project_name_eng = project_name_eng;
                    project.description = description;
                    project.description_eng = description_eng;
                    project.createdAt = new Date();
                    project.updatedAt = new Date();
                    project.images = JSON.stringify(filePaths);
                    await Connection.manager.save(project);
                    res.status(200).json({
                        success: true,
                        message: "add sucess"
                    });
                } catch  {
                    res.json({
                        success: false,
                        message: "token not valid",
                        status: 401
                    });
                }
            } else {
                res.json({
                    success: false,
                    message: "User not found",
                    status: 404
                });
            }
            Connection.isInitialized ? Connection.destroy() : null;
        } else {
            res.status(405).json({
                success: false,
                message: "method not allowed",
                status: 405
            });
        }
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreateProject);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [477], () => (__webpack_exec__(6711)));
module.exports = __webpack_exports__;

})();