(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 919:
/***/ ((module) => {

// Exports
module.exports = {
	"about_us_conteiner": "about-us_about_us_conteiner__nKeYe",
	"about_us_image": "about-us_about_us_image__VjDTJ",
	"about_us_text": "about-us_about_us_text__JwUPu"
};


/***/ }),

/***/ 6060:
/***/ ((module) => {

// Exports
module.exports = {
	"completed_projects_conteiner": "completed-projects_completed_projects_conteiner__ZaFkn",
	"copleted_projects_items": "completed-projects_copleted_projects_items__u0J5u",
	"copleted_project": "completed-projects_copleted_project__28kgq",
	"completed_project_image": "completed-projects_completed_project_image__xfOf3",
	"carousel-paging-dots": "completed-projects_carousel-paging-dots__7Uz89"
};


/***/ }),

/***/ 5273:
/***/ ((module) => {

// Exports
module.exports = {
	"footer_conteiner": "footer_footer_conteiner__74X1_",
	"contact_info_conteiner": "footer_contact_info_conteiner__rKq2i",
	"contact_tools": "footer_contact_tools__aOUm9",
	"contac_info_text": "footer_contac_info_text__kPE3j",
	"contact_info_termsAndCvonditions": "footer_contact_info_termsAndCvonditions__WkX6d",
	"contact_info_address": "footer_contact_info_address__9M3ow",
	"contact_info_emile": "footer_contact_info_emile__bJOFN",
	"contact_info_phone": "footer_contact_info_phone__xFDv6"
};


/***/ }),

/***/ 762:
/***/ ((module) => {

// Exports
module.exports = {
	"header_conteiner": "header_header_conteiner__xKWy5",
	"header_menu_conteiner": "header_header_menu_conteiner__V5rng",
	"header_menu": "header_header_menu__EoIor",
	"header_menu_list": "header_header_menu_list__8h7o7",
	"header_logo_conteiner": "header_header_logo_conteiner__puUbj",
	"header_menu_item": "header_header_menu_item__vKbKX",
	"switch_language_button": "header_switch_language_button__lLelN",
	"header_menu_switch_language": "header_header_menu_switch_language__Vxsd_"
};


/***/ }),

/***/ 1624:
/***/ ((module) => {

// Exports
module.exports = {
	"mainsection_conteiner": "mainsection_mainsection_conteiner__BAEPU",
	"mainsection_contact_conteiner": "mainsection_mainsection_contact_conteiner__0uFe_",
	"mainsection_image_conteiner": "mainsection_mainsection_image_conteiner__qhZvW",
	"mainsection_contact_title": "mainsection_mainsection_contact_title__4B_Al",
	"mainsection_contact_text": "mainsection_mainsection_contact_text__ag6UW"
};


/***/ }),

/***/ 9680:
/***/ ((module) => {

// Exports
module.exports = {
	"userssection_conteiner": "userssection_userssection_conteiner__Fhvb3",
	"userssection_title": "userssection_userssection_title__X0yOk",
	"userssection_item": "userssection_userssection_item__KCMX_",
	"current_user": "userssection_current_user__OrCDP"
};


/***/ }),

/***/ 7784:
/***/ ((module) => {

// Exports
module.exports = {
	"users_section": "Index_users_section__hfSa0",
	"header": "Index_header__qIxKk",
	"footer_section": "Index_footer_section__i__Vw"
};


/***/ }),

/***/ 9976:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": () => (/* binding */ ScrollContext),
/* harmony export */   "I": () => (/* binding */ ScrollProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const ScrollContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(null);
const ScrollProvider = ({ children  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ScrollContext.Provider, {
        value: ScrollContext,
        children: children
    });
};


/***/ }),

/***/ 7503:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
// EXTERNAL MODULE: ./styles/Index.module.css
var Index_module = __webpack_require__(7784);
var Index_module_default = /*#__PURE__*/__webpack_require__.n(Index_module);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./components/front/header/header.module.css
var header_module = __webpack_require__(762);
var header_module_default = /*#__PURE__*/__webpack_require__.n(header_module);
// EXTERNAL MODULE: ./components/button/button.component.tsx
var button_component = __webpack_require__(5154);
// EXTERNAL MODULE: ./context/scroll-context.tsx
var scroll_context = __webpack_require__(9976);
// EXTERNAL MODULE: ./context/locale-context.tsx
var locale_context = __webpack_require__(4757);
// EXTERNAL MODULE: external "nookies"
var external_nookies_ = __webpack_require__(3053);
var external_nookies_default = /*#__PURE__*/__webpack_require__.n(external_nookies_);
;// CONCATENATED MODULE: ./utils/app.util.ts

const switchLanguage = (setLocale)=>{
    const locale = external_nookies_default().get({}).locale;
    if (locale === "ka") {
        setLocale("en");
        external_nookies_default().set(null, "locale", "en", {
            path: "/"
        });
    } else {
        setLocale("ka");
        external_nookies_default().set(null, "locale", "ka", {
            path: "/"
        });
    }
};
function ModalCloseHendler(param) {
    param(false);
}

;// CONCATENATED MODULE: ./components/front/header/header.component.tsx








const Header = (props)=>{
    const { 0: scrollRefs , 1: setScrollRefs  } = (0,external_react_.useState)(null);
    const { 0: localeKey , 1: setLocaleKey  } = (0,external_react_.useState)("");
    const { 0: dictionary , 1: setDictionary  } = (0,external_react_.useState)(null);
    const scrollContext = (0,external_react_.useContext)(scroll_context/* ScrollContext */.$);
    const localeContextObject = (0,external_react_.useContext)(locale_context/* localeContext */.A);
    (0,external_react_.useEffect)(()=>{
        setScrollRefs(scrollContext);
        setLocaleKey(localeContextObject.localeKey);
        setDictionary(localeContextObject.dictionary);
    }, [
        scrollContext,
        localeContextObject
    ]);
    const scrollTo = (ref)=>{
        return ref ? window.scrollTo({
            top: ref.current?.offsetTop - 100,
            behavior: "smooth"
        }) : null;
    };
    const openModalHeader = ()=>{
        props.setismodalopen(true);
        props.setModalKey("FORM");
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (header_module_default()).header_conteiner,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (header_module_default()).header_logo_conteiner,
                onClick: ()=>{
                    scrollTo(scrollRefs.mainSection);
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: "/images/logo.svg",
                    alt: "main logo",
                    width: 180,
                    height: 30
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (header_module_default()).header_menu,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: (header_module_default()).header_menu_list,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: (header_module_default()).header_menu_item,
                                onClick: ()=>{
                                    scrollTo(scrollRefs.userSection);
                                },
                                children: dictionary ? dictionary[localeKey]["aourUsers"] : null
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: (header_module_default()).header_menu_item,
                                onClick: ()=>{
                                    scrollTo(scrollRefs.projectsSection);
                                },
                                children: dictionary ? dictionary[localeKey]["galery"] : null
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: (header_module_default()).header_menu_item,
                                onClick: ()=>{
                                    scrollTo(scrollRefs.aboutUs);
                                },
                                children: dictionary ? dictionary[localeKey]["aboutUs"] : "ჩვენს შესახებ"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (header_module_default()).header_menu_switch_language,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: (header_module_default()).switch_language_button,
                            onClick: ()=>{
                                switchLanguage(localeContextObject.setLocaleKey);
                            },
                            children: localeKey
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(button_component/* default */.Z, {
                        name: dictionary ? dictionary[localeKey]["contactUs"] : "დაგვიკავშირდით",
                        hendler: openModalHeader
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const header_component = (Header);

// EXTERNAL MODULE: ./components/front/mainsection/mainsection.module.css
var mainsection_module = __webpack_require__(1624);
var mainsection_module_default = /*#__PURE__*/__webpack_require__.n(mainsection_module);
;// CONCATENATED MODULE: ./components/front/mainsection/mainsection.component.tsx







const Mainsection = (props)=>{
    const { 0: localeKey , 1: setLocaleKey  } = (0,external_react_.useState)("");
    const { 0: dictionary , 1: setDictionary  } = (0,external_react_.useState)(null);
    const localeContextObject = (0,external_react_.useContext)(locale_context/* localeContext */.A);
    (0,external_react_.useEffect)(()=>{
        setLocaleKey(localeContextObject.localeKey);
        setDictionary(localeContextObject.dictionary);
    }, [
        localeContextObject
    ]);
    const mainSection = /*#__PURE__*/ (0,external_react_.createRef)();
    const scrollContext = (0,external_react_.useContext)(scroll_context/* ScrollContext */.$);
    scrollContext.mainSection = mainSection;
    const openModalHeader = ()=>{
        props.setismodalopen(true);
        props.setModalKey("FORM");
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (mainsection_module_default()).mainsection_conteiner,
        id: "main_section",
        ref: mainSection,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (mainsection_module_default()).mainsection_contact_conteiner,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: (mainsection_module_default()).mainsection_contact_title,
                        children: "გამტანერი"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: (mainsection_module_default()).mainsection_contact_text,
                        children: [
                            "ნარჩენების მართვის კომპანია „გამტანერის“ მთავარი ფასეულობა უხვად დაგროვილი თეორიული ცოდნისა და პრაქტიკული გამოცდილების მარაგია.",
                            " "
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(button_component/* default */.Z, {
                        name: dictionary ? dictionary[localeKey]["contactUs"] : "დაგვიკავშირდით",
                        hendler: openModalHeader
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (mainsection_module_default()).mainsection_image_conteiner,
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: "/images/main-grid.png",
                    alt: "mainsection-grid",
                    width: 700,
                    height: 550
                })
            })
        ]
    });
};
/* harmony default export */ const mainsection_component = (Mainsection);

// EXTERNAL MODULE: ./components/front/userssection/userssection.module.css
var userssection_module = __webpack_require__(9680);
var userssection_module_default = /*#__PURE__*/__webpack_require__.n(userssection_module);
;// CONCATENATED MODULE: external "nuka-carousel/lib/carousel"
const carousel_namespaceObject = require("nuka-carousel/lib/carousel");
var carousel_default = /*#__PURE__*/__webpack_require__.n(carousel_namespaceObject);
;// CONCATENATED MODULE: ./config/global.config.ts
const styles = {
    fill: "#206F52",
    position: "relative",
    top: "70px"
};
const CaruselConfig = {
    containerClassName: "carousel-container",
    nextButtonClassName: "carousel-next-button",
    nextButtonText: "შემდეგი",
    pagingDotsClassName: "carousel-paging-dots",
    pagingDotsContainerClassName: "carousel-paging-dots-container",
    prevButtonClassName: "carousel-prev-button",
    prevButtonText: "წინა",
    pagingDotsStyle: styles
};

;// CONCATENATED MODULE: ./components/front/userssection/userssection.component.tsx







const UsersSection = (props)=>{
    const userSection = /*#__PURE__*/ (0,external_react_.createRef)();
    const scrollContext = (0,external_react_.useContext)(scroll_context/* ScrollContext */.$);
    scrollContext.userSection = userSection;
    const { 0: users , 1: setUsers  } = (0,external_react_.useState)(null);
    const { localeKey  } = (0,external_react_.useContext)(locale_context/* localeContext */.A);
    (0,external_react_.useEffect)(()=>{
        setUsers(props.users);
    }, [
        props.users
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (userssection_module_default()).userssection_conteiner,
        ref: userSection,
        id: "users_section",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (userssection_module_default()).userssection_title,
                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    children: "ჩვენი მომხმარებლები"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((carousel_default()), {
                slidesToShow: 3,
                adaptiveHeight: true,
                defaultControlsConfig: CaruselConfig,
                renderCenterLeftControls: ({})=>null,
                renderCenterRightControls: ({})=>null,
                children: users ? users.map((user)=>{
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (userssection_module_default()).current_user,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                children: localeKey === "en" ? user.title_eng : user.title
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: user.createdAt
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: localeKey === "en" ? user.description_eng : user.description
                            })
                        ]
                    }, user.id);
                }) : null
            })
        ]
    });
};
/* harmony default export */ const userssection_component = (UsersSection);

// EXTERNAL MODULE: ./components/front/completedprojects/completed-projects.module.css
var completed_projects_module = __webpack_require__(6060);
var completed_projects_module_default = /*#__PURE__*/__webpack_require__.n(completed_projects_module);
;// CONCATENATED MODULE: ./components/front/completedprojects/completed-projects.component.tsx








const CompletedProjects = (props)=>{
    const imagesStyle = {
        borderRadius: "8px",
        overflow: "hidden"
    };
    const projectsSection = /*#__PURE__*/ (0,external_react_.createRef)();
    const scrollContext = (0,external_react_.useContext)(scroll_context/* ScrollContext */.$);
    scrollContext.projectsSection = projectsSection;
    const { localeKey  } = (0,external_react_.useContext)(locale_context/* localeContext */.A);
    const { 0: projects , 1: setProjects  } = (0,external_react_.useState)(null);
    (0,external_react_.useEffect)(()=>{
        setProjects(props.projects);
    }, [
        props.projects
    ]);
    const openProjectHendler = ()=>{
        props.setismodalopen(true);
        props.setModalKey("GALLERY");
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (completed_projects_module_default()).completed_projects_conteiner,
        ref: projectsSection,
        id: "completed_projects",
        children: /*#__PURE__*/ jsx_runtime_.jsx((carousel_default()), {
            adaptiveHeight: true,
            defaultControlsConfig: CaruselConfig,
            slidesToShow: 3,
            renderCenterLeftControls: ()=>null,
            renderCenterRightControls: ()=>null,
            children: projects ? projects.map((project)=>{
                return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (completed_projects_module_default()).copleted_project,
                    onClick: openProjectHendler,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (completed_projects_module_default()).completed_project_image,
                        style: imagesStyle,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: "/uploads/project_one.jpg",
                                alt: localeKey === "en" ? project.project_name_eng : project.project_name,
                                width: 300,
                                height: 150,
                                sizes: "100vw",
                                layout: "responsive",
                                priority: true
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                children: localeKey === "en" ? project.description_eng : project.description
                            })
                        ]
                    })
                }, project.id);
            }) : null
        })
    });
};
/* harmony default export */ const completed_projects_component = (CompletedProjects);

// EXTERNAL MODULE: ./components/front/aboutus/about-us.module.css
var about_us_module = __webpack_require__(919);
var about_us_module_default = /*#__PURE__*/__webpack_require__.n(about_us_module);
;// CONCATENATED MODULE: ./components/front/aboutus/about-us.component.tsx






const AboutUs = (props)=>{
    const imagesStyle = {
        borderRadius: "8px",
        overflow: "hidden"
    };
    const aboutUs = /*#__PURE__*/ (0,external_react_.createRef)();
    const scrollContext = (0,external_react_.useContext)(scroll_context/* ScrollContext */.$);
    scrollContext.aboutUs = aboutUs;
    const { localeKey  } = (0,external_react_.useContext)(locale_context/* localeContext */.A);
    const { 0: data , 1: setData  } = (0,external_react_.useState)(null);
    (0,external_react_.useEffect)(()=>{
        setData(props.data);
    }, [
        props.data
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (about_us_module_default()).about_us_conteiner,
        ref: aboutUs,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (about_us_module_default()).about_us_image,
                style: imagesStyle,
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: "/images/about-us.jpg",
                    alt: "about-us",
                    width: 600,
                    height: 500,
                    sizes: "100vw"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (about_us_module_default()).about_us_text,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        children: localeKey === "en" ? data?.title_eng : data?.title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: localeKey === "en" ? data?.description_eng : data?.description
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const about_us_component = (AboutUs);

// EXTERNAL MODULE: ./components/front/footer/footer.module.css
var footer_module = __webpack_require__(5273);
var footer_module_default = /*#__PURE__*/__webpack_require__.n(footer_module);
// EXTERNAL MODULE: ./components/form/form.component.tsx
var form_component = __webpack_require__(9555);
;// CONCATENATED MODULE: ./components/front/footer/footer.component.tsx






const Footer = (props)=>{
    const formInputs = [
        {
            id: "001",
            type: "text",
            name: "fullname",
            className: "form-input",
            placeholder: props.dictionary ? props.dictionary[props.localeKey]["fullName"] : "სახელი და გვარი",
            needCommonParent: true
        },
        {
            id: "002",
            type: "text",
            name: "phone",
            className: "form-input",
            placeholder: props.dictionary ? props.dictionary[props.localeKey]["phone"] : "ტელეფონი",
            needCommonParent: true
        },
        {
            id: "003",
            type: "email",
            name: "email",
            className: "form-input",
            placeholder: props.dictionary ? props.dictionary[props.localeKey]["email"] : "ელ.ფოსტა",
            needCommonParent: false
        }, 
    ];
    const formTextareas = [
        {
            id: Date.now().toString(36) + Math.random().toString(36).slice(2),
            textareaClass: "form_textarea",
            textareaName: "message",
            textareaPlaceholder: props.dictionary ? props.dictionary[props.localeKey]["message"] : "შეტყობინება"
        }, 
    ];
    const formProps = {
        formClassName: "form",
        inputs: formInputs,
        inputsCommonParentClass: "inputs_common_parent",
        needTextareas: true,
        textareas: formTextareas,
        needButton: true,
        buttonClass: "form_button",
        buttonText: props.dictionary ? props.dictionary[props.localeKey]["send"] : "გაგზავნა",
        ButtoncallBack: (e)=>{
            e.preventDefault();
            console.log("clicked");
        }
    };
    const { 0: contacts , 1: setContacts  } = (0,external_react_.useState)(null);
    const { localeKey  } = (0,external_react_.useContext)(locale_context/* localeContext */.A);
    (0,external_react_.useEffect)(()=>{
        setContacts(props.contacts);
    }, [
        props.contacts
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        className: (footer_module_default()).footer_conteiner,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (footer_module_default()).contact_info_conteiner,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        children: props.dictionary ? props.dictionary[props.localeKey]["contact"] : "საკონტაქტო"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (footer_module_default()).contact_tools,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (footer_module_default()).contact_info_address,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: "/images/location_on.svg",
                                        alt: "location",
                                        width: 24,
                                        height: 24,
                                        layout: "fixed"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: localeKey === "en" ? contacts?.address_eng : contacts?.address
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (footer_module_default()).contact_info_emile,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: "/images/email.svg",
                                        alt: "email",
                                        width: 24,
                                        height: 24,
                                        layout: "fixed"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: contacts?.email
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (footer_module_default()).contact_info_phone,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: "/images/call.svg",
                                        alt: "call",
                                        width: 24,
                                        height: 24,
                                        layout: "fixed"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: contacts?.phone
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (footer_module_default()).contac_info_text,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: localeKey === "en" ? contacts?.description_eng : contacts?.description
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (footer_module_default()).contact_info_termsAndCvonditions,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: props.dictionary ? props.dictionary[props.localeKey]["termsAndConditions"] : "წესები და პირობები"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: props.dictionary ? props.dictionary[props.localeKey]["allRightsRecevd"] : "ყველა უფლება დაცულია"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (footer_module_default()).contact_us,
                children: /*#__PURE__*/ jsx_runtime_.jsx(form_component/* default */.Z, {
                    FormProps: formProps
                })
            })
        ]
    });
};
/* harmony default export */ const footer_component = (Footer);

// EXTERNAL MODULE: ./components/modal/modal.component.tsx + 1 modules
var modal_component = __webpack_require__(4461);
;// CONCATENATED MODULE: ./pages/index.tsx













const Home = (props)=>{
    const { 0: localeKey , 1: setLocaleKey  } = (0,external_react_.useState)("");
    const { 0: dictionary , 1: setDictionary  } = (0,external_react_.useState)(null);
    const { 0: isModalOpen , 1: setIsModalOpen  } = (0,external_react_.useState)(false);
    const { 0: modalKey , 1: setModalKey  } = (0,external_react_.useState)("");
    const localeContextObject = (0,external_react_.useContext)(locale_context/* localeContext */.A);
    (0,external_react_.useEffect)(()=>{
        setLocaleKey(localeContextObject.localeKey);
        setDictionary(localeContextObject.dictionary);
    }, [
        localeContextObject
    ]);
    const ModalCloseHendler = ()=>{
        setIsModalOpen(false);
    };
    const footerProps = {
        dyctionary: dictionary,
        key: localeKey
    };
    const formInputs = [
        {
            id: "001",
            type: "text",
            name: "fullname",
            className: "form-input",
            placeholder: dictionary ? dictionary[localeKey]["fullName"] : "სახელი და გვარი",
            needCommonParent: true
        },
        {
            id: "002",
            type: "text",
            name: "phone",
            className: "form-input",
            placeholder: dictionary ? dictionary[localeKey]["phone"] : "ტელეფონი",
            needCommonParent: true
        },
        {
            id: "003",
            type: "email",
            name: "email",
            className: "form-input",
            placeholder: dictionary ? dictionary[localeKey]["email"] : "ელ.ფოსტა",
            needCommonParent: false
        }, 
    ];
    const formTextareas = [
        {
            textareaClass: "form_textarea",
            textareaName: "message",
            textareaPlaceholder: dictionary ? dictionary[localeKey]["message"] : "შეტყობინება"
        }, 
    ];
    const close = {
        closeClassname: "form_close",
        closeLogoClassname: "footer_close_logo",
        closeSrc: "/images/close.svg",
        hendler: ModalCloseHendler
    };
    const formProps = {
        needClose: true,
        ...close,
        formClassName: "form",
        inputs: formInputs,
        inputsCommonParentClass: "inputs_common_parent",
        needTextareas: true,
        textareas: formTextareas,
        needButton: true,
        buttonClass: "form_button",
        buttonText: dictionary ? dictionary[localeKey]["send"] : "გაგზავნა",
        ButtoncallBack: (e)=>{
            e.preventDefault();
        }
    };
    const modalProps = {
        modal_title: "ჩვენს შესახებ",
        FormProps: formProps,
        isOpen: isModalOpen,
        key: modalKey
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "conteiner",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(modal_component/* default */.Z, {
                modalprops: modalProps
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "გამტანერი"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Generated by create next app"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Index_module_default()).header,
                children: /*#__PURE__*/ jsx_runtime_.jsx(header_component, {
                    setismodalopen: setIsModalOpen,
                    setModalKey: setModalKey
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: (Index_module_default()).main_section,
                children: /*#__PURE__*/ jsx_runtime_.jsx(mainsection_component, {
                    setismodalopen: setIsModalOpen,
                    setModalKey: setModalKey
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: (Index_module_default()).users_section,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(userssection_component, {
                        users: props.ourUsers
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: (Index_module_default()).projects_section,
                children: /*#__PURE__*/ jsx_runtime_.jsx(completed_projects_component, {
                    setismodalopen: setIsModalOpen,
                    setModalKey: setModalKey,
                    projects: props.projects
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: (Index_module_default()).about_us_section,
                children: /*#__PURE__*/ jsx_runtime_.jsx(about_us_component, {
                    data: props.aboutus
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: (Index_module_default()).footer_section,
                children: /*#__PURE__*/ jsx_runtime_.jsx(footer_component, {
                    dictionary: footerProps.dyctionary,
                    localeKey: footerProps.key,
                    contacts: props.contacts
                })
            })
        ]
    });
};
async function getServerSideProps({ req  }) {
    const loacale = external_nookies_default().get(null, "locale")["locale"] === "en" ? "en" : "ka";
    const projects = await fetch("http://localhost:3000/api/client/projects/getall", {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            "set-cookie": `HttpOnly;Secure;locale=${external_nookies_default().get(null, "locale")["locale"] ? external_nookies_default().get(null, "locale")["locale"] : "ka"}`
        }
    }).then((response)=>response.json()).then((data)=>data);
    const ourUsers = await fetch("http://localhost:3000/api/client/users/getall", {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            "set-cookie": `HttpOnly;Secure;locale=${external_nookies_default().get(null, "locale")["locale"]}`
        }
    }).then((response)=>response.json()).then((data)=>data);
    const contacts = await fetch("http://localhost:3000/api/client/contacts/get", {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            "set-cookie": `HttpOnly;Secure;locale=${external_nookies_default().get(null, "locale")["locale"]}`
        }
    }).then((response)=>response.json()).then((data)=>data);
    const aboutus = await fetch("http://localhost:3000/api/client/aboutus/get", {
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        }
    }).then((response)=>response.json()).then((data)=>data);
    return {
        props: {
            projects: projects.resource,
            ourUsers: ourUsers.resource,
            contacts: contacts.resource,
            aboutus: aboutus.resource
        }
    };
}
/* harmony default export */ const pages = (Home);


/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 3053:
/***/ ((module) => {

"use strict";
module.exports = require("nookies");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 1223:
/***/ ((module) => {

"use strict";
module.exports = require("react-loader-spinner");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [675,757,555,426], () => (__webpack_exec__(7503)));
module.exports = __webpack_exports__;

})();