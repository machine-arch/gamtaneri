import { NextPage } from "next";

const SingUp: NextPage = () => {
  return (
    <>
      <h1>singUp</h1>
    </>
  );
};

export default SingUp;
