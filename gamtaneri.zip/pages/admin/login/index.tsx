import Login from "../../../components/admin/login/login.component";
import { AuthProvider } from "../../../context/admin/auth.context";

const LoginPage = () => {
  return (
    <>
      <Login />
    </>
  );
};
export default LoginPage;
