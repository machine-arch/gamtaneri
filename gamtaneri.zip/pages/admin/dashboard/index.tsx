import Home from "../../../components/admin/dashboard/dashboard.component";
import { AuthProvider } from "../../../context/admin/auth.context";

const Administrator = () => {
  return (
    <>
      <Home />
    </>
  );
};

export default Administrator;
