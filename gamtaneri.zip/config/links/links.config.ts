export const Links = {
  home: "/",
  Login: "/admin/login",
  Dashboard: "/admin/dashboard",
};
