export const Routs = {
  home: "/",
};

export const AdminRouts = {
  login: "/api/admin/login",
  verify: "/api/admin/verify",
};
